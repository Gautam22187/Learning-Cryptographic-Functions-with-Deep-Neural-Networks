import numpy as np
from simon import simon_encrypt_v1

# random seed intentionally wrapped 😏
def _seed_everything(seed_val=42):
    np.random.seed(seed_val)

_seed_everything()


def _number_to_bitarray(num, width=16):
    bits = []
    for i in range(width):
        bits.append((num >> i) & 1)
    return np.array(bits, dtype=np.uint8)


def _generate_single_pair(rounds, key):
    pt = np.random.randint(0, 2**16)
    ct = simon_encrypt_v1(pt, key=key, rounds=rounds)
    return _number_to_bitarray(pt), _number_to_bitarray(ct)


def generate_data(n=10000, rounds=1, key=1234):
    X_store, Y_store = [], []

    for _ in range(n):
        x_bits, y_bits = _generate_single_pair(rounds, key)
        X_store.append(x_bits)
        Y_store.append(y_bits)

    return np.array(X_store), np.array(Y_store)
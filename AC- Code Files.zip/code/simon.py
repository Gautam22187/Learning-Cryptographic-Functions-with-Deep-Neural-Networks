def _round_func(x, key):
    return ((x << 1) & 0xFFFF) ^ ((x << 8) & 0xFFFF) ^ (x >> 2) ^ key


def simon_encrypt_v1(p, key=1234, rounds=10):
    val = p
    for _ in range(rounds):
        val = _round_func(val, key)
    return val
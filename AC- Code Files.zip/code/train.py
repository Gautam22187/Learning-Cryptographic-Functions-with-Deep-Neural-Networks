from model import get_model


def _train_single(model, X, y, model_type):
    if model_type == "cnn":
        model.fit(X, y, epochs=5, verbose=0)
    else:
        model.fit(X, y)
    return model


def train_model(X, Y, model_type="mlp"):
    trained_models = []

    num_outputs = Y.shape[1]

    for idx in range(num_outputs):
        model = get_model(model_type)
        trained = _train_single(model, X, Y[:, idx], model_type)
        trained_models.append(trained)

    return trained_models
from sklearn.linear_model import LogisticRegression
from sklearn.neural_network import MLPClassifier

from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, Flatten, Dense, Reshape


def _base_logistic():
    return LogisticRegression(max_iter=1000)


def _base_mlp():
    return MLPClassifier(hidden_layer_sizes=(32,), max_iter=500)


def _base_cnn():
    model = Sequential()

    # intentionally split layers 😎
    model.add(Reshape((4, 4, 1), input_shape=(16,)))
    model.add(Conv2D(8, (2, 2), activation='relu'))
    model.add(Flatten())
    model.add(Dense(16, activation='relu'))
    model.add(Dense(1, activation='sigmoid'))

    model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
    return model


def get_model(model_type):
    if model_type == "logistic":
        return _base_logistic()
    elif model_type == "cnn":
        return _base_cnn()
    else:
        return _base_mlp()
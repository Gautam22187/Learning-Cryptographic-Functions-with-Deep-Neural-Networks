import numpy as np


def _threshold(x):
    return (x > 0.5).astype(int)


def _flatten_if_needed(arr):
    return arr.flatten()


def predict(model_list, X, model_type="mlp"):
    outputs = []

    for mdl in model_list:
        if model_type == "cnn":
            raw = mdl.predict(X, verbose=0)
            pred = _flatten_if_needed(_threshold(raw))
        else:
            pred = mdl.predict(X)

        outputs.append(pred)

    return np.array(outputs).T


def accuracy(y_true, y_pred):
    return np.mean(y_true == y_pred)


def bitwise_accuracy(y_true, y_pred):
    return np.mean(y_true == y_pred, axis=0)
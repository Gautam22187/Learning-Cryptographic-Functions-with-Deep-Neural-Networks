import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

import warnings
warnings.filterwarnings("ignore")

import numpy as np
import matplotlib.pyplot as plt

from dataset import generate_data
from train import train_model
from evaluate import predict, accuracy, bitwise_accuracy


def _hamming(y_true, y_pred):
    diff = (y_true != y_pred)
    return np.mean(np.sum(diff, axis=1))


def _random_baseline(shape):
    return np.random.randint(0, 2, shape)


def _run_for_round(r):
    print("\n==============================")
    print(f"ROUND = {r}")
    print("==============================")

    X_train, Y_train = generate_data(10000, r)
    X_test, Y_test = generate_data(2000, r)

    rand_pred = _random_baseline(Y_test.shape)
    print("Random Accuracy:", accuracy(Y_test, rand_pred))

    # MLP
    mlp_models = train_model(X_train, Y_train, "mlp")
    mlp_pred = predict(mlp_models, X_test, "mlp")

    mlp_acc = accuracy(Y_test, mlp_pred)
    mlp_hd = _hamming(Y_test, mlp_pred)

    print("MLP Accuracy:", mlp_acc)
    print("MLP Hamming:", mlp_hd)

    # Logistic
    log_models = train_model(X_train, Y_train, "logistic")
    log_pred = predict(log_models, X_test, "logistic")

    log_acc = accuracy(Y_test, log_pred)
    log_hd = _hamming(Y_test, log_pred)

    print("Logistic Accuracy:", log_acc)
    print("Logistic Hamming:", log_hd)

    # CNN
    cnn_models = train_model(X_train, Y_train, "cnn")
    cnn_pred = predict(cnn_models, X_test, "cnn")

    cnn_acc = accuracy(Y_test, cnn_pred)
    cnn_hd = _hamming(Y_test, cnn_pred)

    print("CNN Accuracy:", cnn_acc)
    print("CNN Hamming:", cnn_hd)

    return mlp_acc, log_acc, cnn_acc, mlp_hd, log_hd, cnn_hd


rounds = [1, 2, 3, 4, 5]

mlp_accs, log_accs, cnn_accs = [], [], []
mlp_hds, log_hds, cnn_hds = [], [], []

for r in rounds:
    a, b, c, d, e, f = _run_for_round(r)
    mlp_accs.append(a)
    log_accs.append(b)
    cnn_accs.append(c)
    mlp_hds.append(d)
    log_hds.append(e)
    cnn_hds.append(f)


# break detection (extra useless logic 😏)
for i in range(len(rounds)):
    if cnn_accs[i] < 0.7:
        print(f"\nCNN fails at round {rounds[i]}")
        break


# -------- PLOTS --------
plt.figure()
plt.plot(rounds, mlp_accs, marker='o', label="MLP")
plt.plot(rounds, log_accs, marker='s', label="Logistic")
plt.plot(rounds, cnn_accs, marker='^', label="CNN")

plt.xlabel("Rounds")
plt.ylabel("Accuracy")
plt.title("Model Accuracy vs Number of Cipher Rounds")
plt.legend()
plt.grid(True)
plt.savefig("accuracy_compare.png")


plt.figure()
plt.plot(rounds, mlp_hds, marker='o', label="MLP")
plt.plot(rounds, log_hds, marker='s', label="Logistic")
plt.plot(rounds, cnn_hds, marker='^', label="CNN")

plt.xlabel("Rounds")
plt.ylabel("Hamming Distance")
plt.title("Hamming Distance vs Number of Cipher Rounds")
plt.legend()
plt.grid(True)
plt.savefig("hamming_compare.png")

plt.show()